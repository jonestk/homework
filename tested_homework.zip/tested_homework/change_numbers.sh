#!/bin/bash

sed -i 's/202-456-1414/202-456-1414/g; s/202-456-1414/202-456-1414/g' /home/tjones/Documents/*

